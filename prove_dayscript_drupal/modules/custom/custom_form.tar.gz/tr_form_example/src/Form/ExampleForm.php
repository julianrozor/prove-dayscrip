<?php

namespace Drupal\tr_form_examples\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Implements an example form.
 */
class ExampleForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'example_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {    
    $form['name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Name'),
      '#description' => $this->t('Add your name '),
      '#maxlength' => 64,
      '#size' => 64,
    ];
    $form['identification'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Indetification'),
      '#description' => $this->t('Add the identification'),
      '#maxlength' => 64,
      '#size' => 64,
    ];    
    $form['date_birthday'] = [
      '#type' => 'date',
      '#title' => $this->t('Birthday'),
      '#description' => $this->t('Birthday'),
      '#maxlength' => 64,
      '#size' => 64,
    ];    
    $form['rol'] = [
      '#type' => 'select',
      '#options' => array(
        'admin' => 'Administrador',
        'webm' => 'Webmaster',
        'developer' => 'Desarrollador',                
        ),
      '#title' => $this->t('Rol'),
    ];  

    // Group submit handlers in an actions element with a key of "actions" so
    // that it gets styled correctly, and so that other modules may add actions
    // to the form. This is not required, but is convention.
    $form['actions'] = [
      '#type' => 'actions',
    ];

    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    $name = $form_state->getValue('name');
    $Id = $form_state->getValue('identification');

    if (strlen($name) < 10) {
      // Set an error for the form element with a key of "name".
      $form_state->setErrorByName('name', $this->t('The name must be at least 10 characters long.'));
    }
    if (!is_numeric($Id)) {
      // Set an error for the form element with a key of "name".
      $form_state->setErrorByName('identification', $this->t('The identification must be at only numbers'));
    }    
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Display result.
    $dataInsert = array();
    foreach ($form_state->getValues() as $key => $value) {
      if(!strpos($key ,'form') && !strpos($key ,'op') && !strpos($key ,'submit')){
        if(strpos($key ,'rol') && $value == 'admin'){
          $dataInsert['state'] = 1;
        }else{
          $dataInsert[$key] = $value;
        }
        //drupal_set_message($key . ': ' . $value);
      }      
    }
    $conn = Database::getConnection();
    $conn->insert('example_users')->fields($dataInsert)->execute();  
    drupal_set_message('Datos guardados con Exito');
    drupal_set_message('Id de registro '.$conn);
  }

}